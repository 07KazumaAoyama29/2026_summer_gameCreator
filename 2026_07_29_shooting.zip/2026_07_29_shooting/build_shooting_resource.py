from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


RESOURCE_PATH = Path(__file__).with_name("shooting.pyxres")
IMAGE_SIZE = 256


def put(image, x, y, rows):
    for dy, row in enumerate(rows):
        for dx, color in enumerate(row):
            if color != ".":
                image[y + dy][x + dx] = color.lower()


def scale_rows(rows, scale):
    scaled = []
    for row in rows:
        wide_row = "".join(color * scale for color in row)
        for _ in range(scale):
            scaled.append(wide_row)
    return scaled


def make_boss():
    size = 128
    image = [["0" for _ in range(size)] for _ in range(size)]

    def set_pixel(x, y, color):
        if 0 <= x < size and 0 <= y < size:
            image[y][x] = color

    def rect(x, y, w, h, color):
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                set_pixel(xx, yy, color)

    def ellipse(cx, cy, rx, ry, color):
        for yy in range(cy - ry, cy + ry + 1):
            for xx in range(cx - rx, cx + rx + 1):
                if ((xx - cx) * (xx - cx) * ry * ry + (yy - cy) * (yy - cy) * rx * rx) <= rx * rx * ry * ry:
                    set_pixel(xx, yy, color)

    def diamond(cx, cy, rx, ry, color):
        for yy in range(cy - ry, cy + ry + 1):
            for xx in range(cx - rx, cx + rx + 1):
                if abs(xx - cx) * ry + abs(yy - cy) * rx <= rx * ry:
                    set_pixel(xx, yy, color)

    # Wings and hull
    diamond(26, 76, 24, 42, "1")
    diamond(102, 76, 24, 42, "1")
    diamond(26, 76, 18, 32, "d")
    diamond(102, 76, 18, 32, "d")
    ellipse(64, 64, 43, 54, "2")
    ellipse(64, 64, 35, 45, "d")
    ellipse(64, 68, 27, 34, "1")

    # Nose, armor, and core
    diamond(64, 28, 18, 24, "c")
    diamond(64, 35, 13, 16, "7")
    rect(38, 55, 52, 8, "6")
    rect(42, 65, 44, 8, "5")
    ellipse(64, 78, 18, 15, "c")
    ellipse(64, 78, 11, 9, "7")
    ellipse(64, 78, 5, 4, "a")

    # Red eyes and side engines
    ellipse(43, 52, 7, 5, "8")
    ellipse(85, 52, 7, 5, "8")
    ellipse(43, 52, 3, 2, "a")
    ellipse(85, 52, 3, 2, "a")
    rect(23, 91, 17, 14, "5")
    rect(88, 91, 17, 14, "5")
    rect(28, 105, 7, 13, "9")
    rect(93, 105, 7, 13, "9")
    rect(30, 112, 3, 8, "a")
    rect(95, 112, 3, 8, "a")

    # Highlights and outline accents
    for x in range(42, 87):
        set_pixel(x, 20 + abs(x - 64) // 2, "7")
    for y in range(39, 99):
        set_pixel(17 + abs(y - 76) // 2, y, "c")
        set_pixel(110 - abs(y - 76) // 2, y, "c")
    rect(57, 101, 14, 9, "6")
    rect(60, 105, 8, 12, "9")

    return ["".join(row) for row in image]


def main():
    image = [["0" for _ in range(IMAGE_SIZE)] for _ in range(IMAGE_SIZE)]

    player = [
        "0000000c00000000",
        "000000ccc0000000",
        "000000c7c0000000",
        "00000cc7cc000000",
        "00000c777c000000",
        "0000ccc6ccc00000",
        "000cccd6dccc0000",
        "00ccddd6dddcc000",
        "0ccdd1d6d1ddcc00",
        "cdd111d6d111ddc0",
        "0cdd166661ddc00",
        "00ccd6d6d6dcc000",
        "000cc6d6d6cc0000",
        "0000c66666c00000",
        "0000090a09000000",
        "0000000a00000000",
    ]

    bullet = [
        "0000000000000000",
        "0000008800000000",
        "000008cc80000000",
        "0000087780000000",
        "000008cc80000000",
        "000008cc80000000",
        "0000087780000000",
        "000008cc80000000",
        "000008cc80000000",
        "0000087780000000",
        "000008cc80000000",
        "000008cc80000000",
        "0000008800000000",
        "0000002200000000",
        "0000002200000000",
        "0000000000000000",
    ]

    enemy_0 = [
        "0000008800000000",
        "0000087780000000",
        "0000877778000000",
        "0008777777800000",
        "0088222222880000",
        "0822777777228000",
        "8277767767772800",
        "8277777777772800",
        "0882277772288000",
        "0008822228800000",
        "0000088880000000",
        "0000080080000000",
        "0000800008000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
    ]

    enemy_1 = [
        "0000002200000000",
        "000002ff20000000",
        "00002f22f2000000",
        "0002f2552f200000",
        "002f222222f20000",
        "02f25f22f52f0000",
        "2f2222222222f000",
        "2f22f2222f22f000",
        "0222ff22ff222000",
        "0022222222220000",
        "0002222222200000",
        "0000202202000000",
        "0002000000200000",
        "0020000000020000",
        "0000000000000000",
        "0000000000000000",
    ]

    enemy_2 = [
        "0000009900000000",
        "000009aa90000000",
        "00009aaaa9000000",
        "0009a777a900000",
        "009a77777a90000",
        "09aa44aa44aa900",
        "9aa44444444aa90",
        "9a447444744a90",
        "09a4444444a9000",
        "009aa444aa90000",
        "0009aaaa9000000",
        "000090990900000",
        "000900000900000",
        "009000000090000",
        "0000000000000000",
        "0000000000000000",
    ]

    spark = [
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000a00000000",
        "000000aaa0000000",
        "00000a7a7a000000",
        "0000aa777aa00000",
        "00000a7a7a000000",
        "000000aaa0000000",
        "0000000a00000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
    ]

    life = [
        "0000000000000000",
        "0000800000800000",
        "0008880008880000",
        "0088888088888000",
        "0888888888888800",
        "0888888888888800",
        "0888888888888800",
        "0088888888888000",
        "0008888888880000",
        "0000888888800000",
        "0000088888000000",
        "0000008880000000",
        "0000000800000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
    ]

    burst = [
        "0000000800000000",
        "0008000800080000",
        "0000888888800000",
        "0088889998888000",
        "008899aaa9988000",
        "0889aa777aa9880",
        "089aa78887aa980",
        "888a789987a888",
        "089aa78887aa980",
        "0889aa777aa9880",
        "008899aaa9988000",
        "0088889998888000",
        "0000888888800000",
        "0008000800080000",
        "0000000800000000",
        "0000000000000000",
    ]

    boss_bullet = [
        "0000000000000000",
        "0000002200000000",
        "0000028820000000",
        "0000288882000000",
        "0002889988200000",
        "000289aa98200000",
        "000289aa98200000",
        "0002889988200000",
        "0000288882000000",
        "0000028820000000",
        "0000002200000000",
        "0000002200000000",
        "0000008800000000",
        "0000080080000000",
        "0000000000000000",
        "0000000000000000",
    ]

    put(image, 0, 0, scale_rows(player, 2))
    put(image, 32, 0, scale_rows(enemy_0, 2))
    put(image, 64, 0, scale_rows(enemy_1, 2))
    put(image, 96, 0, scale_rows(enemy_2, 2))
    put(image, 128, 0, bullet)
    put(image, 144, 0, spark)
    put(image, 160, 0, life)
    put(image, 176, 0, burst)
    put(image, 192, 0, boss_bullet)
    put(image, 0, 64, make_boss())

    image_text = "\n".join("".join(row) for row in image)

    with ZipFile(RESOURCE_PATH, "w", ZIP_DEFLATED) as archive:
        archive.writestr("pyxel_resource/", "")
        archive.writestr("pyxel_resource/version", "1.8.5")
        archive.writestr("pyxel_resource/image0", image_text)


if __name__ == "__main__":
    main()
